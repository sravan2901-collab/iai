# AI Learning Engine Setup (Open-Source LLM via Ollama)

This adds AI-driven learning-path and lesson-content generation to AksharAI,
using **Ollama** to run an open-source model (Llama 3.1, Mistral, or Gemma 2)
locally — no paid API key required.

## What changed

- `app/services/ai_content_service.py` — new service that talks to your local
  Ollama server and asks it to (1) design a personalized lesson plan from the
  diagnostic results, and (2) write the actual lesson content in the
  learner's chosen language.
- `app/services/learning_path_engine.py` — `generate_learning_path()` now
  tries the AI path first, and **automatically falls back** to the original
  rule-based lesson selection if Ollama is offline, disabled, or returns bad
  output. Nothing breaks if the model isn't running.
- `app/config.py` / `.env` — new settings: `AI_LEARNING_ENGINE_ENABLED`,
  `OLLAMA_BASE_URL`, `OLLAMA_MODEL`, `OLLAMA_TIMEOUT_SECONDS`.

## 1. Install Ollama

- macOS / Windows: download from https://ollama.com/download
- Linux:
  ```bash
  curl -fsSL https://ollama.com/install.sh | sh
  ```

## 2. Pull an open-source model

Pick one based on your machine's RAM/GPU:

```bash
ollama pull llama3.1        # 8B params, ~4.7GB, good general quality
# or, for a lighter machine:
ollama pull gemma2:2b        # ~1.6GB, faster, still solid for short lessons
# or:
ollama pull mistral          # 7B params, strong multilingual output
```

Update `OLLAMA_MODEL` in `.env` to match whichever you pulled.

## 3. Start the Ollama server

```bash
ollama serve
```

It listens on `http://localhost:11434` by default (matches `OLLAMA_BASE_URL`
in `.env`). Leave this running alongside your FastAPI backend.

## 4. Run the backend as usual

```bash
uvicorn app.main:app --reload
```

No other code changes are needed — the next time `generate_learning_path()`
runs (after a learner completes the diagnostic test), it will call the local
model to design the plan and write lesson content in the learner's language,
then persist those lessons and the path exactly like the rule-based path did
before.

## Turning it off

Set `AI_LEARNING_ENGINE_ENABLED=false` in `.env` to skip the AI call entirely
and always use the original rule-based lesson selection (useful for demos on
a machine without Ollama installed, or offline grading).

## Notes on model choice

- Any Ollama-compatible open-source model works — Llama 3.1, Mistral, Gemma 2,
  Qwen 2.5, etc. Larger models (8B+) generally write more fluent, accurate
  content in Indian languages (Hindi, Telugu, Tamil, Marathi, Bengali,
  Kannada); smaller models (2B-3B) are faster but may need more prompt tuning
  for non-English output quality.
- If you'd rather not self-host, the same `ai_content_service.py` interface
  can be pointed at any OpenAI-compatible open-weight hosting endpoint (e.g.
  Groq, Together AI, Hugging Face Inference Endpoints serving Llama/Mistral)
  by swapping the `_generate_json` HTTP call — the JSON contract with the
  rest of the app stays identical.
