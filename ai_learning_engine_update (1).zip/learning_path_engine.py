"""
Learning Path Engine Service for AksharAI Language Literacy Platform.

Generates personalized learning_path and path_lesson sequences for learners
based on their predicted proficiency per skill type.
"""

import asyncio
from typing import Dict, Optional, Any, List
from datetime import datetime, timezone
from sqlalchemy.orm import Session
from sqlalchemy import desc

from app.database import SessionLocal
from app import models
from app.services.proficiency_engine import (
    predict_proficiency,
    get_learner_scores,
    normalize_skill_type,
    CANONICAL_SKILL_TYPES,
)
from app.services.ai_content_service import ai_learning_engine

# Proficiency level ordering from lowest to highest
LEVEL_ORDER = {
    "FOUNDATIONAL": 0,
    "BASIC": 1,
    "INTERMEDIATE": 2,
    "ADVANCED": 3,
}

# Next level mapping for progressive literacy goals
LEVEL_NEXT = {
    "FOUNDATIONAL": "BASIC",
    "BASIC": "INTERMEDIATE",
    "INTERMEDIATE": "ADVANCED",
    "ADVANCED": "ADVANCED",
}

# Difficulty ordering for sorting lessons
DIFFICULTY_ORDER = {
    "FOUNDATIONAL": 1,
    "BASIC": 2,
    "FUNCTIONAL": 2,
    "INTERMEDIATE": 3,
    "PROFICIENT": 4,
    "ADVANCED": 5,
}


def generate_learning_path(learner_id: int, db: Optional[Session] = None) -> int:
    """
    Generates a new personalized learning_path and path_lesson sequence for a learner:
    1. Calls predict_proficiency(learner_id) to get predicted proficiency per skill.
    2. Identifies the learner's weakest skill_type.
    3. Deactivates any existing ACTIVE learning_path by setting status = 'COMPLETED'.
    4. Inserts a new ACTIVE learning_path with current_level = weakest level and
       target_proficiency = next level up.
    5. Selects up to 5 matching lessons for the weakest skill_type, ordered by difficulty.
    6. Inserts path_lesson entries with sequence_no 1..5, status = 'UNLOCKED' for the
       first lesson and 'LOCKED' for subsequent lessons.

    :param learner_id: Unique integer ID of the learner.
    :param db: Optional SQLAlchemy Session. If omitted, uses SessionLocal context.
    :return: Unique path_id integer of the newly generated learning_path.
    """
    close_db = False
    if db is None:
        db = SessionLocal()
        close_db = True

    try:
        # 1. Predict learner's proficiency across all skills
        predictions = predict_proficiency(learner_id, db=db)

        # 2. Determine weakest skill_type
        # Sort by level rank ascending; tiebreak by canonical order
        weakest_skill = min(
            CANONICAL_SKILL_TYPES,
            key=lambda s: LEVEL_ORDER.get(predictions.get(s, "FOUNDATIONAL"), 0)
        )
        weakest_level = predictions.get(weakest_skill, "FOUNDATIONAL")
        target_level = LEVEL_NEXT.get(weakest_level, "BASIC")

        # 3. Complete any existing ACTIVE learning paths for this learner
        active_paths = (
            db.query(models.LearningPath)
            .filter(
                models.LearningPath.learner_id == learner_id,
                models.LearningPath.status == "ACTIVE"
            )
            .all()
        )
        for ap in active_paths:
            ap.status = "COMPLETED"
        db.commit()

        # 4. Insert new ACTIVE learning_path
        new_path = models.LearningPath(
            learner_id=learner_id,
            target_proficiency=target_level,
            current_level=weakest_level,
            completion_percentage=0.0,
            status="ACTIVE",
            generated_on=datetime.now(timezone.utc)
        )
        db.add(new_path)
        db.commit()
        db.refresh(new_path)

        # 5. Fetch learner and current language
        learner = db.query(models.Learner).filter(models.Learner.learner_id == learner_id).first()
        lang_id = learner.current_lang_id if (learner and learner.current_lang_id) else 2  # Default to English (2)

        language = db.query(models.Language).filter(models.Language.lang_id == lang_id).first()
        language_name = language.lang_name if language else "English"

        curriculum = db.query(models.Curriculum).filter(models.Curriculum.lang_id == lang_id).first()

        modules: List[models.Module] = []
        target_modules: List[models.Module] = []
        if curriculum:
            modules = (
                db.query(models.Module)
                .filter(models.Module.curriculum_id == curriculum.curriculum_id)
                .all()
            )
            target_modules = [
                m for m in modules
                if normalize_skill_type(m.skill_type) == weakest_skill
            ]
            if not target_modules:
                target_modules = modules  # Fallback to all modules if specific skill module missing

        # 5a. Try AI-generated lesson plan (open-source LLM via Ollama) first.
        # Falls back to the deterministic rule-based selection below whenever
        # the model is disabled, unreachable, or returns unusable output.
        selected_lessons = _try_generate_ai_lessons(
            db=db,
            weakest_skill=weakest_skill,
            weakest_level=weakest_level,
            target_level=target_level,
            language_name=language_name,
            target_modules=target_modules,
            curriculum=curriculum,
            lang_id=lang_id,
            learner_id=learner_id,
        )

        if not selected_lessons:
            # Rule-based fallback: reuse existing lessons already in the DB.
            candidate_lessons: List[models.Lesson] = []
            for mod in target_modules:
                mod_lessons = (
                    db.query(models.Lesson)
                    .filter(models.Lesson.module_id == mod.module_id)
                    .all()
                )
                candidate_lessons.extend(mod_lessons)

            # Sort candidate lessons by difficulty level ascending
            candidate_lessons.sort(
                key=lambda l: DIFFICULTY_ORDER.get((l.difficulty_level or "").upper(), 99)
            )

            # Take top 5 lessons
            selected_lessons = candidate_lessons[:5]

        # 6. Insert path_lesson rows
        for idx, lesson_obj in enumerate(selected_lessons):
            seq_no = idx + 1
            lesson_status = "UNLOCKED" if seq_no == 1 else "LOCKED"

            pl = models.PathLesson(
                path_id=new_path.path_id,
                lesson_id=lesson_obj.lesson_id,
                sequence_no=seq_no,
                status=lesson_status
            )
            db.add(pl)

        db.commit()
        return new_path.path_id

    finally:
        if close_db:
            db.close()


def _run_async(coro):
    """Runs an async coroutine from sync code, whether or not a loop is already running."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)
    else:
        # We're already inside an event loop (e.g. called from an async FastAPI
        # route). Run the coroutine in a fresh loop on a separate thread so we
        # don't need this whole call chain to become async.
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(asyncio.run, coro).result()


def _try_generate_ai_lessons(
    db: Session,
    weakest_skill: str,
    weakest_level: str,
    target_level: str,
    language_name: str,
    target_modules: List[models.Module],
    curriculum: Optional[models.Curriculum],
    lang_id: int,
    learner_id: int,
) -> List[models.Lesson]:
    """
    Asks the AI learning engine for a lesson plan + content in the learner's
    language, persists any new lessons under a matching module, and returns
    them as ordered Lesson rows. Returns [] if AI generation isn't usable,
    so the caller falls back to the rule-based lesson selection.
    """
    try:
        scores = get_learner_scores(learner_id, db=db)

        plan = _run_async(ai_learning_engine.generate_path_plan(
            weakest_skill=weakest_skill,
            current_level=weakest_level,
            target_level=target_level,
            language_name=language_name,
            skill_scores=scores,
        ))
        if not plan:
            return []

        # Find (or create) a module to attach AI-generated lessons to.
        module = target_modules[0] if target_modules else None
        if module is None and curriculum is not None:
            module = models.Module(
                curriculum_id=curriculum.curriculum_id,
                module_name=f"{weakest_skill} (AI-generated)",
                sequence_no=(
                    db.query(models.Module)
                    .filter(models.Module.curriculum_id == curriculum.curriculum_id)
                    .count() + 1
                ),
                skill_type=weakest_skill,
            )
            db.add(module)
            db.commit()
            db.refresh(module)
        if module is None:
            return []  # No curriculum for this language at all; can't attach lessons.

        new_lessons: List[models.Lesson] = []
        for item in plan:
            content = _run_async(ai_learning_engine.generate_lesson_content(
                title=item["title"],
                skill_type=weakest_skill,
                difficulty_level=item.get("difficulty_level", weakest_level),
                language_name=language_name,
            ))
            if not content:
                continue  # Skip lessons whose content generation failed; keep the rest.

            lesson = models.Lesson(
                module_id=module.module_id,
                title=item["title"],
                content_type="AI_GENERATED",
                target_text=content["target_text"],
                phonetic_script=content.get("phonetic_script"),
                difficulty_level=item.get("difficulty_level", weakest_level),
            )
            db.add(lesson)
            new_lessons.append(lesson)

        if not new_lessons:
            return []

        db.commit()
        for lesson in new_lessons:
            db.refresh(lesson)

        return new_lessons[:5]

    except Exception as e:
        # Never let an AI/content-generation failure break learning-path
        # creation — just fall back to the deterministic rule-based path.
        print(f"AI learning path generation failed, falling back to rule-based selection: {e}")
        return []


def get_active_path(learner_id: int, db: Optional[Session] = None) -> Optional[Dict[str, Any]]:
    """
    Retrieves the current ACTIVE learning_path for a learner along with its ordered path_lesson list
    (joined with lesson details: title, content_type, difficulty_level, etc.).

    :param learner_id: Unique integer ID of the learner.
    :param db: Optional SQLAlchemy Session. If omitted, uses SessionLocal context.
    :return: Dictionary representation of active learning_path or None if no active path exists.
    """
    close_db = False
    if db is None:
        db = SessionLocal()
        close_db = True

    try:
        active_path = (
            db.query(models.LearningPath)
            .filter(
                models.LearningPath.learner_id == learner_id,
                models.LearningPath.status == "ACTIVE"
            )
            .order_by(desc(models.LearningPath.path_id))
            .first()
        )

        if not active_path:
            return None

        # Query path_lesson entries joined with lesson
        path_lessons_query = (
            db.query(models.PathLesson, models.Lesson)
            .join(models.Lesson, models.PathLesson.lesson_id == models.Lesson.lesson_id)
            .filter(models.PathLesson.path_id == active_path.path_id)
            .order_by(models.PathLesson.sequence_no)
            .all()
        )

        ordered_lessons = []
        for pl, l in path_lessons_query:
            ordered_lessons.append({
                "path_lesson_id": pl.path_lesson_id,
                "lesson_id": l.lesson_id,
                "sequence_no": pl.sequence_no,
                "status": pl.status,
                "title": l.title,
                "content_type": l.content_type,
                "difficulty_level": l.difficulty_level,
                "target_text": l.target_text,
                "content_url": l.content_url
            })

        return {
            "path_id": active_path.path_id,
            "learner_id": active_path.learner_id,
            "target_proficiency": active_path.target_proficiency,
            "current_level": active_path.current_level,
            "status": active_path.status,
            "completion_percentage": float(active_path.completion_percentage or 0.0),
            "generated_on": active_path.generated_on.isoformat() if active_path.generated_on else None,
            "path_lessons": ordered_lessons
        }

    finally:
        if close_db:
            db.close()
