"""
AI Content & Learning Path Generation Service for AksharAI Language Literacy Platform.

Wraps an open-source, self-hosted LLM (served locally via Ollama, e.g. Llama 3.1,
Mistral, or Gemma 2) to:
  1. Turn a learner's diagnostic-test results into a personalized learning-path plan
     (which skill to focus on, why, and an ordered list of lesson topics).
  2. Generate the actual lesson content (target reading text, phonetic/syllable
     breakdown, and a short comprehension check) for a given skill + difficulty +
     language, so content isn't limited to what's hard-coded in
     content_repository.py.

Design notes:
  - No proprietary API key is required. Ollama runs the model locally/on your own
    server, which keeps this fully open-source and free to run (see
    AI_MODEL_SETUP.md for install steps).
  - Every call degrades gracefully: if Ollama is unreachable, the model isn't
    pulled yet, or it returns malformed JSON, these functions return None so the
    caller (learning_path_engine.py) can fall back to the existing rule-based
    logic. The platform never breaks because the AI model is offline.
  - Follows the same httpx + settings-driven pattern used in sarvam_service.py.
"""

import json
import re
from typing import Any, Dict, List, Optional

import httpx

from app.config import settings

# Skill-specific prompt guidance so generated content actually targets the
# right kind of exercise instead of generic text.
SKILL_GUIDANCE = {
    "Reading & Pronunciation": (
        "a short passage (1-2 sentences) designed for reading aloud and "
        "pronunciation practice, with natural syllable/phoneme breaks"
    ),
    "Word Formation": (
        "a short passage (1-2 sentences) that showcases root words, prefixes, "
        "suffixes, or vocabulary-building patterns"
    ),
    "Grammar": (
        "a short passage (1-2 sentences) that demonstrates a specific grammar "
        "or sentence-structure rule appropriate to the difficulty level"
    ),
    "Literature": (
        "a short literary passage (2-3 sentences) suitable for comprehension "
        "and expressive reading practice"
    ),
}


class AILearningEngineService:
    """Thin client for a local open-source LLM served via Ollama's REST API."""

    def __init__(self) -> None:
        self.base_url = settings.OLLAMA_BASE_URL.rstrip("/")
        self.model = settings.OLLAMA_MODEL
        self.enabled = settings.AI_LEARNING_ENGINE_ENABLED
        self.timeout = settings.OLLAMA_TIMEOUT_SECONDS

    # ------------------------------------------------------------------ #
    # Low-level call to Ollama
    # ------------------------------------------------------------------ #
    async def _generate_json(self, prompt: str, system: str) -> Optional[Any]:
        """
        Calls POST /api/generate on a local Ollama server and parses the
        response as JSON. Returns None on any failure (connection, timeout,
        non-200, unparsable JSON) so callers can fall back gracefully.
        """
        if not self.enabled:
            return None

        payload = {
            "model": self.model,
            "system": system,
            "prompt": prompt,
            "format": "json",   # Ollama constrains output to valid JSON
            "stream": False,
            "options": {"temperature": 0.4},
        }

        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(f"{self.base_url}/api/generate", json=payload)
                if response.status_code != 200:
                    print(f"AI learning engine: Ollama returned {response.status_code}")
                    return None
                raw_text = response.json().get("response", "")
        except Exception as e:
            print(f"AI learning engine: Ollama call failed ({e}). Falling back to rule-based logic.")
            return None

        return self._safe_json_parse(raw_text)

    @staticmethod
    def _safe_json_parse(raw_text: str) -> Optional[Any]:
        """Parses model output as JSON, tolerating stray markdown fences."""
        if not raw_text:
            return None
        cleaned = raw_text.strip()
        cleaned = re.sub(r"^```(json)?", "", cleaned.strip(), flags=re.IGNORECASE).strip()
        cleaned = re.sub(r"```$", "", cleaned.strip()).strip()
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError:
            # Last resort: grab the first {...} or [...] block in the text
            match = re.search(r"(\{.*\}|\[.*\])", cleaned, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group(1))
                except json.JSONDecodeError:
                    return None
            return None

    # ------------------------------------------------------------------ #
    # 1. Diagnostic results -> personalized learning-path plan
    # ------------------------------------------------------------------ #
    async def generate_path_plan(
        self,
        weakest_skill: str,
        current_level: str,
        target_level: str,
        language_name: str,
        skill_scores: Dict[str, float],
        lesson_count: int = 5,
    ) -> Optional[List[Dict[str, str]]]:
        """
        Asks the model for an ordered list of `lesson_count` lesson topics that
        take a learner from current_level to target_level in weakest_skill,
        in the learner's chosen language.

        Returns a list of dicts like:
          [{"title": "...", "difficulty_level": "BASIC", "focus": "..."}, ...]
        or None if generation failed.
        """
        system = (
            "You are a curriculum designer for an adult literacy platform. "
            "You design short, encouraging, level-appropriate lesson sequences. "
            "Always respond with ONLY a JSON array, no commentary."
        )
        prompt = (
            f"Learner diagnostic results (0-100 scale) by skill: {json.dumps(skill_scores)}.\n"
            f"Weakest skill: {weakest_skill}.\n"
            f"Current proficiency level: {current_level}. Target level: {target_level}.\n"
            f"Learning language: {language_name}.\n\n"
            f"Design exactly {lesson_count} lessons, ordered from easiest to hardest, "
            f"that progress the learner from {current_level} toward {target_level} in "
            f"'{weakest_skill}'. Respond as a JSON array of {lesson_count} objects, each with:\n"
            '  "title": short lesson title in ' + language_name + ',\n'
            '  "difficulty_level": one of FOUNDATIONAL, BASIC, INTERMEDIATE, ADVANCED,\n'
            '  "focus": one short phrase describing what the lesson practices.'
        )

        result = await self._generate_json(prompt, system)
        if not isinstance(result, list) or not result:
            return None

        cleaned: List[Dict[str, str]] = []
        for item in result[:lesson_count]:
            if isinstance(item, dict) and item.get("title"):
                cleaned.append({
                    "title": str(item.get("title"))[:150],
                    "difficulty_level": str(item.get("difficulty_level", current_level)).upper(),
                    "focus": str(item.get("focus", ""))[:255],
                })
        return cleaned or None

    # ------------------------------------------------------------------ #
    # 2. Lesson topic -> actual lesson content, in-language
    # ------------------------------------------------------------------ #
    async def generate_lesson_content(
        self,
        title: str,
        skill_type: str,
        difficulty_level: str,
        language_name: str,
    ) -> Optional[Dict[str, str]]:
        """
        Generates the actual reading/practice content for one lesson, written
        natively in the learner's target language.

        Returns a dict like:
          {"target_text": "...", "phonetic_script": "syl-la-ble breakdown",
           "comprehension_question": "..."}
        or None if generation failed.
        """
        guidance = SKILL_GUIDANCE.get(skill_type, "a short passage appropriate to the skill")
        system = (
            "You are a literacy content writer for adult and first-generation learners. "
            "You write natively in the requested language, at the requested difficulty. "
            "Always respond with ONLY a JSON object, no commentary."
        )
        prompt = (
            f"Write {guidance}, in {language_name}, at {difficulty_level} difficulty, "
            f"for a lesson titled '{title}' (skill focus: {skill_type}).\n\n"
            "Respond as a JSON object with exactly these keys:\n"
            '  "target_text": the passage, written in ' + language_name + ',\n'
            '  "phonetic_script": the same passage broken into syllables/phonemes '
            'separated by hyphens, to aid pronunciation,\n'
            '  "comprehension_question": one short question (in ' + language_name + ') '
            "checking understanding of the passage."
        )

        result = await self._generate_json(prompt, system)
        if not isinstance(result, dict) or not result.get("target_text"):
            return None

        return {
            "target_text": str(result.get("target_text"))[:2000],
            "phonetic_script": str(result.get("phonetic_script", ""))[:2000],
            "comprehension_question": str(result.get("comprehension_question", ""))[:500],
        }


ai_learning_engine = AILearningEngineService()
